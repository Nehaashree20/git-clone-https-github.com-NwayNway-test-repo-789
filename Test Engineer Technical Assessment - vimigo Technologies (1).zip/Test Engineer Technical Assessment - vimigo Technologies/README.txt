Setting up your assessment:

1. Please append this folder name with your name.
Example: Tengku Syafiq - Test Engineer Technical Assessment - vimigo Technologies

2. Run: git clone ./materials/post_service.bundle ./submissions/post_service

3. Read README.md in the project to run the project locally.


Submitting your assessment:
1. please bundle your project with: git bundle create your_name_repo.bundle --all
2. copy the generated .bundle into ./submissions/
3. Please put all documents and all related files into ./submissions folder,
2. Finally delete the ./submissions/post_service folder, since we only need the bundle file. (Kindly backup on your side just in case)



Goodluck!